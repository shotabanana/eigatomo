class GroupsController < ApplicationController
  def show
  end

  def edit
  end

  def index
  end
end
