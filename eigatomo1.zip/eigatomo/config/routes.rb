Rails.application.routes.draw do
  devise_for :users
  root to: 'homes#top', as: :top
  get 'home/about', to: 'homes#about'
  resources :users, only: [:show, :edit, :update]
  resources :groups, only: [:show, :edit, :update, :index, :create, :destroy]
end
