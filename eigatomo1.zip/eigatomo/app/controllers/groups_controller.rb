class GroupsController < ApplicationController
  def show
    @group = Group.find(params[:id])
    @place = Place.find(@group.place_id)
    @users = @group.users
    @user = User.find(@group.mainuser_id)
  end

  def edit
  end

  def create
    @group = Group.new(group_params)
    @group.mainuser_id = current_user.id
    @user = User.find(current_user.id)
    @group.mainuser_name = @user.name
    @group.users = [current_user]
    @group.save
    redirect_to group_path(@group.id)
  end

  def index
    @groups = Group.all
  end

  private
  def group_params
    params.require(:group).permit(:people, :age, :theatre, :sex, :movie, :memo, :time, :place_id, user_ids:[], room_ids:[])
  end

end
