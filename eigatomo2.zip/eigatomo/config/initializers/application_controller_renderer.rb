# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'ae9c9c2b1854d7056edec20a597ac543d150acbf847a2b83d050b476de074f2ececab79b38170dc01b19fd63619b528a8be175bffb7071694375925881bf19c9'