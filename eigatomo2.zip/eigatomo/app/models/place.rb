class Place < ApplicationRecord
  has_many :groups
end
